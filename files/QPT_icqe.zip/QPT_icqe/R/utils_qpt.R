build_model_matrix_single_modality <- function(events, task_row, selected_nodes, window_size,
                                               modality_col, modality_value) {
    focal_row <- task_row$row_in_horizon
    focal_row_id <- task_row$row_id
    horizon_id <- task_row$horizon_id
    
    context <- events %>%
        dplyr::filter(horizon_id == !!horizon_id) %>%
        dplyr::arrange(row_in_horizon)
    
    start_row <- max(1, focal_row - window_size + 1)
    
    included <- context %>%
        dplyr::filter(row_in_horizon >= start_row, row_in_horizon <= focal_row)
    
    prior_rows <- included %>%
        dplyr::filter(row_in_horizon < focal_row) %>%
        dplyr::filter(as.character(.data[[modality_col]]) == as.character(modality_value))
    
    focal <- included %>%
        dplyr::filter(row_id == focal_row_id)
    
    mat <- empty_adjacency(selected_nodes)
    
    if (nrow(focal) == 0 || length(selected_nodes) == 0) {
        return(mat)
    }
    
    if (nrow(prior_rows) == 0) {
        return(mat)
    }
    
    prior_active <- colSums(prior_rows[, selected_nodes, drop = FALSE], na.rm = TRUE) > 0
    prior_active <- as.logical(prior_active)
    names(prior_active) <- selected_nodes
    
    focal_active <- as.numeric(focal[1, selected_nodes, drop = FALSE])
    focal_active <- focal_active > 0
    names(focal_active) <- selected_nodes
    
    for (src in selected_nodes) {
        for (tgt in selected_nodes) {
            if (isTRUE(prior_active[src]) && isTRUE(focal_active[tgt])) {
                mat[src, tgt] <- 1L
            }
        }
    }
    
    mat
}

build_model_matrix_general <- function(events, task_row, selected_nodes, window_size) {
    focal_row <- task_row$row_in_horizon
    focal_row_id <- task_row$row_id
    horizon_id <- task_row$horizon_id
    
    context <- events %>%
        dplyr::filter(horizon_id == !!horizon_id) %>%
        dplyr::arrange(row_in_horizon)
    
    start_row <- max(1, focal_row - window_size + 1)
    
    included <- context %>%
        dplyr::filter(row_in_horizon >= start_row, row_in_horizon <= focal_row)
    
    prior_rows <- included %>%
        dplyr::filter(row_in_horizon < focal_row)
    
    focal <- included %>%
        dplyr::filter(row_id == focal_row_id)
    
    mat <- empty_adjacency(selected_nodes)
    
    if (nrow(focal) == 0 || length(selected_nodes) == 0) {
        return(mat)
    }
    
    if (nrow(prior_rows) == 0) {
        return(mat)
    }
    
    prior_active <- colSums(prior_rows[, selected_nodes, drop = FALSE], na.rm = TRUE) > 0
    prior_active <- as.logical(prior_active)
    names(prior_active) <- selected_nodes
    
    focal_active <- as.numeric(focal[1, selected_nodes, drop = FALSE])
    focal_active <- focal_active > 0
    names(focal_active) <- selected_nodes
    
    for (src in selected_nodes) {
        for (tgt in selected_nodes) {
            if (isTRUE(prior_active[src]) && isTRUE(focal_active[tgt])) {
                mat[src, tgt] <- 1L
            }
        }
    }
    
    mat
}

combine_model_matrices <- function(mats, selected_nodes) {
    out <- empty_adjacency(selected_nodes)
    
    if (length(mats) == 0) {
        return(out)
    }
    
    for (mat in mats) {
        out <- ((out + mat) > 0) * 1L
    }
    
    rownames(out) <- selected_nodes
    colnames(out) <- selected_nodes
    out
}

compute_task_loss_avg <- function(human_mat, model_mat) {
    if (length(human_mat) == 0) {
        return(0)
    }
    
    n_possible <- nrow(human_mat) * ncol(human_mat)
    
    if (n_possible == 0) {
        return(0)
    }
    
    sum(abs(human_mat - model_mat)) / n_possible
}

evaluate_general_window <- function(events, tasks, annotations, window_size) {
    task_losses <- numeric(nrow(tasks))
    
    for (i in seq_len(nrow(tasks))) {
        task_row <- tasks[i, , drop = FALSE]
        task_id <- task_row$task_id
        
        task_ann <- annotations[[task_id]]
        selected_nodes <- task_ann$nodes
        human_mat <- task_ann$human_mat
        
        model_mat <- build_model_matrix_general(
            events = events,
            task_row = task_row,
            selected_nodes = selected_nodes,
            window_size = window_size
        )
        
        task_losses[i] <- compute_task_loss_avg(human_mat, model_mat)
    }
    
    tibble::tibble(
        window = window_size,
        mean_loss = mean(task_losses)
    )
}

evaluate_window_combination <- function(events, tasks, annotations,
                                        modality_col, modality_values,
                                        windows_named) {
    task_losses <- numeric(nrow(tasks))
    
    for (i in seq_len(nrow(tasks))) {
        task_row <- tasks[i, , drop = FALSE]
        task_id <- task_row$task_id
        
        task_ann <- annotations[[task_id]]
        selected_nodes <- task_ann$nodes
        human_mat <- task_ann$human_mat
        
        modality_mats <- purrr::map(modality_values, function(mod_val) {
            build_model_matrix_single_modality(
                events = events,
                task_row = task_row,
                selected_nodes = selected_nodes,
                window_size = windows_named[[mod_val]],
                modality_col = modality_col,
                modality_value = mod_val
            )
        })
        
        model_mat <- combine_model_matrices(modality_mats, selected_nodes)
        task_losses[i] <- compute_task_loss_avg(human_mat, model_mat)
    }
    
    tibble::as_tibble(as.list(windows_named)) %>%
        dplyr::mutate(mean_loss = mean(task_losses))
}

make_window_grid <- function(candidate_lists) {
    expand.grid(
        candidate_lists,
        KEEP.OUT.ATTRS = FALSE,
        stringsAsFactors = FALSE
    )
}

generate_neighbors <- function(current_windows, k_max) {
    mods <- names(current_windows)
    neighbors <- list()
    idx <- 1
    
    for (mod in mods) {
        for (step in c(-1, 1)) {
            candidate <- current_windows
            candidate[[mod]] <- candidate[[mod]] + step
            
            if (candidate[[mod]] >= 1 && candidate[[mod]] <= k_max) {
                neighbors[[idx]] <- candidate
                idx <- idx + 1
            }
        }
    }
    
    if (length(neighbors) == 0) {
        return(list())
    }
    
    seen <- character(0)
    unique_neighbors <- list()
    
    for (cand in neighbors) {
        key <- paste(names(cand), unlist(cand), collapse = "|")
        if (!key %in% seen) {
            seen <- c(seen, key)
            unique_neighbors[[length(unique_neighbors) + 1]] <- cand
        }
    }
    
    unique_neighbors
}

generate_general_neighbors <- function(current_window, k_max) {
    neighbors <- c(current_window - 1, current_window + 1)
    neighbors <- neighbors[neighbors >= 1 & neighbors <= k_max]
    unique(neighbors)
}

hill_climb_windows <- function(events, tasks, annotations,
                               modality_col, modality_values,
                               start_windows, k_max,
                               max_iter = 50) {
    current <- start_windows
    current_eval <- evaluate_window_combination(
        events = events,
        tasks = tasks,
        annotations = annotations,
        modality_col = modality_col,
        modality_values = modality_values,
        windows_named = current
    )
    
    history <- list(current_eval)
    
    for (iter in seq_len(max_iter)) {
        neighbors <- generate_neighbors(current, k_max)
        
        if (length(neighbors) == 0) {
            break
        }
        
        neighbor_results <- purrr::map_dfr(neighbors, function(w) {
            evaluate_window_combination(
                events = events,
                tasks = tasks,
                annotations = annotations,
                modality_col = modality_col,
                modality_values = modality_values,
                windows_named = w
            )
        })
        
        best_neighbor <- neighbor_results %>%
            dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
        
        if (best_neighbor$mean_loss[1] + 1e-12 < current_eval$mean_loss[1]) {
            current <- as.list(best_neighbor[1, modality_values, drop = FALSE])
            current_eval <- best_neighbor
            history[[length(history) + 1]] <- best_neighbor
        } else {
            break
        }
    }
    
    list(
        best = current_eval,
        history = dplyr::bind_rows(history)
    )
}

hill_climb_general_window <- function(events, tasks, annotations,
                                      start_window, k_max,
                                      max_iter = 50) {
    current <- start_window
    current_eval <- evaluate_general_window(
        events = events,
        tasks = tasks,
        annotations = annotations,
        window_size = current
    )
    
    history <- list(current_eval)
    
    for (iter in seq_len(max_iter)) {
        neighbors <- generate_general_neighbors(current, k_max)
        
        if (length(neighbors) == 0) {
            break
        }
        
        neighbor_results <- purrr::map_dfr(neighbors, function(w) {
            evaluate_general_window(
                events = events,
                tasks = tasks,
                annotations = annotations,
                window_size = w
            )
        })
        
        best_neighbor <- neighbor_results %>%
            dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
        
        if (best_neighbor$mean_loss[1] + 1e-12 < current_eval$mean_loss[1]) {
            current <- best_neighbor$window[1]
            current_eval <- best_neighbor
            history[[length(history) + 1]] <- best_neighbor
        } else {
            break
        }
    }
    
    list(
        best = current_eval,
        history = dplyr::bind_rows(history)
    )
}

optimize_window_combinations_coarse_to_fine <- function(
        events, tasks, annotations,
        modality_col, modality_values,
        coarse_points = 10,
        refine_radius = 3,
        do_hill_climb = TRUE,
        hill_max_iter = 75
) {
    stopifnot(length(modality_values) >= 1)
    
    k_max <- max(tasks$row_in_horizon)
    
    if (k_max <= coarse_points) {
        coarse_seq <- seq_len(k_max)
    } else {
        coarse_seq <- unique(round(seq(1, k_max, length.out = coarse_points)))
        coarse_seq <- coarse_seq[coarse_seq >= 1 & coarse_seq <= k_max]
    }
    
    coarse_candidates <- setNames(
        replicate(length(modality_values), coarse_seq, simplify = FALSE),
        modality_values
    )
    
    coarse_grid <- make_window_grid(coarse_candidates)
    
    coarse_results <- purrr::map_dfr(seq_len(nrow(coarse_grid)), function(i) {
        windows_named <- as.list(coarse_grid[i, , drop = FALSE])
        evaluate_window_combination(
            events = events,
            tasks = tasks,
            annotations = annotations,
            modality_col = modality_col,
            modality_values = modality_values,
            windows_named = windows_named
        )
    })
    
    best_coarse <- coarse_results %>%
        dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
    
    refine_candidates <- purrr::map(modality_values, function(mod_val) {
        center <- best_coarse[[mod_val]][1]
        seq(
            max(1, center - refine_radius),
            min(k_max, center + refine_radius)
        )
    })
    names(refine_candidates) <- modality_values
    
    refine_grid <- make_window_grid(refine_candidates)
    
    refine_results <- purrr::map_dfr(seq_len(nrow(refine_grid)), function(i) {
        windows_named <- as.list(refine_grid[i, , drop = FALSE])
        evaluate_window_combination(
            events = events,
            tasks = tasks,
            annotations = annotations,
            modality_col = modality_col,
            modality_values = modality_values,
            windows_named = windows_named
        )
    })
    
    best_refined <- refine_results %>%
        dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
    
    best_final <- best_refined
    hill_results <- NULL
    search_method <- "coarse_to_fine"
    
    if (do_hill_climb) {
        start_windows <- as.list(best_refined[1, modality_values, drop = FALSE])
        
        hill_out <- hill_climb_windows(
            events = events,
            tasks = tasks,
            annotations = annotations,
            modality_col = modality_col,
            modality_values = modality_values,
            start_windows = start_windows,
            k_max = k_max,
            max_iter = hill_max_iter
        )
        
        hill_results <- hill_out$history
        best_final <- hill_out$best
        search_method <- "coarse_to_fine_hill"
    }
    
    list(
        k_max = k_max,
        coarse_seq = coarse_seq,
        coarse_results = coarse_results,
        refine_results = refine_results,
        hill_results = hill_results,
        best_windows = best_final,
        search_method = search_method
    )
}

optimize_general_window_coarse_to_fine <- function(
        events, tasks, annotations,
        coarse_points = 10,
        refine_radius = 3,
        do_hill_climb = TRUE,
        hill_max_iter = 75
) {
    k_max <- max(tasks$row_in_horizon)
    
    if (k_max <= coarse_points) {
        coarse_seq <- seq_len(k_max)
    } else {
        coarse_seq <- unique(round(seq(1, k_max, length.out = coarse_points)))
        coarse_seq <- coarse_seq[coarse_seq >= 1 & coarse_seq <= k_max]
    }
    
    coarse_results <- purrr::map_dfr(coarse_seq, function(w) {
        evaluate_general_window(
            events = events,
            tasks = tasks,
            annotations = annotations,
            window_size = w
        )
    })
    
    best_coarse <- coarse_results %>%
        dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
    
    refine_seq <- seq(
        max(1, best_coarse$window[1] - refine_radius),
        min(k_max, best_coarse$window[1] + refine_radius)
    )
    
    refine_results <- purrr::map_dfr(refine_seq, function(w) {
        evaluate_general_window(
            events = events,
            tasks = tasks,
            annotations = annotations,
            window_size = w
        )
    })
    
    best_refined <- refine_results %>%
        dplyr::slice_min(order_by = mean_loss, n = 1, with_ties = FALSE)
    
    best_final <- best_refined
    hill_results <- NULL
    search_method <- "general_coarse_to_fine"
    
    if (do_hill_climb) {
        hill_out <- hill_climb_general_window(
            events = events,
            tasks = tasks,
            annotations = annotations,
            start_window = best_refined$window[1],
            k_max = k_max,
            max_iter = hill_max_iter
        )
        
        hill_results <- hill_out$history
        best_final <- hill_out$best
        search_method <- "general_coarse_to_fine_hill"
    }
    
    list(
        k_max = k_max,
        coarse_seq = coarse_seq,
        coarse_results = coarse_results,
        refine_results = refine_results,
        hill_results = hill_results,
        best_windows = best_final,
        search_method = search_method
    )
}