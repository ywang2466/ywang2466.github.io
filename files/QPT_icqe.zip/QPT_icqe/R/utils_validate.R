validate_uploaded_data <- function(df) {
    messages <- character(0)
    
    out <- df
    
    if ("Start" %in% names(out)) {
        original_non_missing <- !is.na(out$Start)
        out$Start <- suppressWarnings(as.numeric(out$Start))
        if (any(is.na(out$Start) & original_non_missing)) {
            messages <- c(messages, "Column Start could not be fully coerced to numeric. Fallback ordering may be used.")
        }
    } else {
        messages <- c(messages, "Column Start not found. A fallback Start index will be created.")
    }
    
    if ("EventIndex" %in% names(out)) {
        original_non_missing <- !is.na(out$EventIndex)
        out$EventIndex <- suppressWarnings(as.numeric(out$EventIndex))
        if (any(is.na(out$EventIndex) & original_non_missing)) {
            messages <- c(messages, "Column EventIndex could not be fully coerced to numeric. Fallback ordering may be used.")
        }
    } else {
        messages <- c(messages, "Column EventIndex not found. A fallback EventIndex will be created.")
    }
    
    if ("unique_index" %in% names(out)) {
        original_non_missing <- !is.na(out$unique_index)
        out$unique_index <- suppressWarnings(as.numeric(out$unique_index))
        if (any(is.na(out$unique_index) & original_non_missing)) {
            messages <- c(messages, "Column unique_index could not be fully coerced to numeric. Fallback unique row IDs may be used.")
        }
    } else {
        messages <- c(messages, "Column unique_index not found. A fallback unique_index will be created.")
    }
    
    if (length(messages) == 0) {
        messages <- c(messages, "Upload checks passed.")
    }
    
    list(
        ok = TRUE,
        messages = messages,
        data = out
    )
}