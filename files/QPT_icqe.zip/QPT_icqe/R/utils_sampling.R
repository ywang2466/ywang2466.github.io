sample_tasks <- function(df, n_tasks = 20, seed = 123) {
    set.seed(seed)
    
    eligible <- df %>%
        filter(eligible_for_sampling)
    
    if (nrow(eligible) == 0) {
        stop("No eligible rows found for sampling.")
    }
    
    n_take <- min(n_tasks, nrow(eligible))
    
    sampled <- eligible %>%
        slice_sample(n = n_take) %>%
        arrange(horizon_id, row_in_horizon) %>%
        mutate(task_id = paste0("task_", seq_len(n()))) %>%
        select(
            task_id,
            row_id,
            horizon_id,
            row_in_horizon,
            Start,
            EventIndex,
            unique_index,
            active_code_count,
            everything()
        )
    
    sampled
}

get_task_context <- function(df, task_row) {
    df %>%
        filter(
            horizon_id == task_row$horizon_id,
            row_in_horizon <= task_row$row_in_horizon
        ) %>%
        mutate(is_focal = row_id == task_row$row_id)
}