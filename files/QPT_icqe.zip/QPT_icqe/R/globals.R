library(shiny)
library(dplyr)
library(tidyr)
library(purrr)
library(readr)
library(DT)
library(ggplot2)
library(stringr)
library(tibble)
library(visNetwork)
library(htmlwidgets)

BASE_REQUIRED_COLS <- character(0)

DEFAULT_CODE_COLS <- c(
    "StartorRestart",
    "RuleBreak",
    "Deviation",
    "PassedBoundary",
    "Flag",
    "YouObject",
    "YouRule",
    "TextObstacle",
    "BrokenStop",
    "OutsideText",
    "WinText",
    "IsOutside",
    "ObjectObstacle",
    "OtherObstacle"
)